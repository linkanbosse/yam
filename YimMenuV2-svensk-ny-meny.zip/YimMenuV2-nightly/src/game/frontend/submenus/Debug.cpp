#include "Debug.hpp"

#include "Debug/Misc.hpp"
#include "Debug/Globals.hpp"
#include "Debug/Locals.hpp"
#include "Debug/Scripts.hpp"
#include "game/frontend/items/Items.hpp"

namespace YimMenu::Submenus
{
	Debug::Debug() :
		#define ICON_FA_BUG "\xef\x86\x88"
	    Submenu::Submenu("Debug", ICON_FA_BUG)
	{
		AddCategory(BuildMiscMenu());
		AddCategory(BuildGlobalsMenu());
		AddCategory(BuildLocalsMenu());
		AddCategory(BuildScriptsMenu());
	}
}