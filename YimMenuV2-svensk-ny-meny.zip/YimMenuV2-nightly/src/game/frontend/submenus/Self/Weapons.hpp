#pragma once
#include "core/frontend/manager/Category.hpp"
#include "game/frontend/items/Items.hpp"

namespace YimMenu::Submenus
{
	std::vector<std::shared_ptr<Category>> BuildWeaponsCategories();
}