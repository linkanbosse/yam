#include "World.hpp"
#include "game/frontend/items/Items.hpp"
#include "World/SpawnPed.hpp"

namespace YimMenu::Submenus
{
	World::World() :
		#define ICON_FA_GLOBE "\xef\x82\xac"
	    Submenu::Submenu("World", ICON_FA_GLOBE)
	{
		// ---- Environment -----------------------------------------------------
		auto environment = std::make_shared<Category>("Environment");

		auto weatherOpts = std::make_shared<Group>("Weather");
		weatherOpts->AddItem(std::make_shared<ListCommandItem>("weather"_J));
		weatherOpts->AddItem(std::make_shared<ConditionalItem>("forceweather"_J, std::make_shared<CommandItem>("setweather"_J), true));
		weatherOpts->AddItem(std::make_shared<BoolCommandItem>("forceweather"_J));

		auto timeGroup = std::make_shared<Group>("Time of Day");
		timeGroup->AddItem(std::make_shared<IntCommandItem>("networktimehour"_J, "Hour"));
		timeGroup->AddItem(std::make_shared<IntCommandItem>("networktimeminute"_J, "Minute"));
		timeGroup->AddItem(std::make_shared<IntCommandItem>("networktimesecond"_J, "Second"));
		timeGroup->AddItem(std::make_shared<CommandItem>("setnetworktime"_J, "Set Time"));
		timeGroup->AddItem(std::make_shared<BoolCommandItem>("freezenetworktime"_J, "Freeze Time"));

		auto rulesOpts = std::make_shared<Group>("World Rules");
		rulesOpts->AddItem(std::make_shared<BoolCommandItem>("pedsignore"_J));
		rulesOpts->AddItem(std::make_shared<BoolCommandItem>("PedRiotMode"_J));
		rulesOpts->AddItem(std::make_shared<BoolCommandItem>("CopsDispatch"_J));
		rulesOpts->AddItem(std::make_shared<BoolCommandItem>("infiniteboundary"_J));
		rulesOpts->AddItem(std::make_shared<BoolCommandItem>("enablecreatordevmode"_J));

		environment->AddItem(std::move(weatherOpts));
		environment->AddItem(std::move(timeGroup));
		environment->AddItem(std::move(rulesOpts));

		// ---- Entities --------------------------------------------------------
		auto entities = std::make_shared<Category>("Entities");

		auto killPeds = std::make_shared<Group>("Kill Peds");
		killPeds->AddItem(std::make_shared<CommandItem>("killallpeds"_J));
		killPeds->AddItem(std::make_shared<CommandItem>("killallenemies"_J));
		auto bringOpts = std::make_shared<Group>("Bring to Me");
		bringOpts->AddItem(std::make_shared<CommandItem>("bringpeds"_J));
		bringOpts->AddItem(std::make_shared<CommandItem>("bringvehs"_J));
		bringOpts->AddItem(std::make_shared<CommandItem>("bringobjs"_J));
		auto deleteOpts = std::make_shared<Group>("Delete");
		deleteOpts->AddItem(std::make_shared<CommandItem>("delpeds"_J));
		deleteOpts->AddItem(std::make_shared<CommandItem>("delvehs"_J));
		deleteOpts->AddItem(std::make_shared<CommandItem>("delobjs"_J));
		deleteOpts->AddItem(std::make_shared<CommandItem>("delcams"_J));

		entities->AddItem(std::move(bringOpts));
		entities->AddItem(std::move(deleteOpts));
		entities->AddItem(std::move(killPeds));

		// ---- Interiors -------------------------------------------------------
		auto interiors = std::make_shared<Category>("Interiors");
		auto iplGroup = std::make_shared<Group>("Interior (IPL) Loader");
		iplGroup->AddItem(std::make_shared<ListCommandItem>("iplselector"_J));
		iplGroup->AddItem(std::make_shared<CommandItem>("loadipl"_J));
		iplGroup->AddItem(std::make_shared<CommandItem>("unloadipl"_J));
		iplGroup->AddItem(std::make_shared<CommandItem>("ipltp"_J));
		interiors->AddItem(std::move(iplGroup));

		AddCategory(std::move(environment));
		AddCategory(std::move(entities));
		AddCategory(std::move(BuildSpawnPedMenu()));
		AddCategory(std::move(interiors));
	}
};