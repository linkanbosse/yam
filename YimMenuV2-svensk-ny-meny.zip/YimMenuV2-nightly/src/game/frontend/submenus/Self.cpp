#include "Self.hpp"

#include "core/util/Joaat.hpp"
#include "game/frontend/items/Items.hpp"
#include "Self/OutfitEditor.hpp"
#include "Self/Weapons.hpp"

namespace YimMenu::Submenus
{
	Self::Self() :
		#define ICON_FA_USER "\xef\x80\x87"
	    Submenu::Submenu("Self", ICON_FA_USER)
	{
		// ---- General ---------------------------------------------------------
		auto general = std::make_shared<Category>("General");

		auto statusGroup = std::make_shared<Group>("Protection & Status");
		statusGroup->AddItem(std::make_shared<BoolCommandItem>("godmode"_J));
		statusGroup->AddItem(std::make_shared<BoolCommandItem>("invis"_J));
		statusGroup->AddItem(std::make_shared<ConditionalItem>("invis"_J, std::make_shared<BoolCommandItem>("localvis"_J)));
		statusGroup->AddItem(std::make_shared<BoolCommandItem>("otr"_J));
		statusGroup->AddItem(std::make_shared<BoolCommandItem>("noragdoll"_J));
		statusGroup->AddItem(std::make_shared<BoolCommandItem>("unlimitedoxygen"_J));
		statusGroup->AddItem(std::make_shared<BoolCommandItem>("disablecriticalhits"_J));

		auto actionsGroup = std::make_shared<Group>("Quick Actions");
		actionsGroup->AddItem(std::make_shared<CommandItem>("heal"_J));
		actionsGroup->AddItem(std::make_shared<CommandItem>("cleardamage"_J));
		actionsGroup->AddItem(std::make_shared<CommandItem>("fillinventory"_J));
		actionsGroup->AddItem(std::make_shared<CommandItem>("openwardrobe"_J));
		actionsGroup->AddItem(std::make_shared<CommandItem>("skipcutscene"_J));
		actionsGroup->AddItem(std::make_shared<CommandItem>("skipconversation"_J));
		actionsGroup->AddItem(std::make_shared<CommandItem>("suicide"_J));

		auto comfortGroup = std::make_shared<Group>("Convenience");
		comfortGroup->AddItem(std::make_shared<BoolCommandItem>("noidlekick"_J));
		comfortGroup->AddItem(std::make_shared<BoolCommandItem>("keepplayerclean"_J));
		comfortGroup->AddItem(std::make_shared<BoolCommandItem>("mobileradio"_J));
		comfortGroup->AddItem(std::make_shared<BoolCommandItem>("formatmoney"_J));

		auto specialAbilityGroup = std::make_shared<Group>("Special Ability");
		specialAbilityGroup->AddItem(std::make_shared<BoolCommandItem>("infspecialability"_J));
		auto specialInMp = std::make_shared<Group>("", 1);
		specialInMp->AddItem(std::make_shared<BoolCommandItem>("mpspecialability"_J, "Enable in MP"));
		specialInMp->AddItem(std::make_shared<ConditionalItem>("mpspecialability"_J, std::make_shared<ListCommandItem>("selspecialability"_J, "##specialselect")));
		specialAbilityGroup->AddItem(std::move(specialInMp));

		general->AddItem(actionsGroup);
		general->AddItem(statusGroup);
		general->AddItem(comfortGroup);
		general->AddItem(specialAbilityGroup);
		AddCategory(std::move(general));

		// ---- Movement --------------------------------------------------------
		auto movement = std::make_shared<Category>("Movement");

		auto movementGroup = std::make_shared<Group>("On Foot");
		movementGroup->AddItem(std::make_shared<BoolCommandItem>("superrun"_J));
		movementGroup->AddItem(std::make_shared<ConditionalItem>("superrun"_J, std::make_shared<FloatCommandItem>("moverateoverride"_J, std::nullopt, false)));
		movementGroup->AddItem(std::make_shared<ConditionalItem>("superrun"_J, std::make_shared<FloatCommandItem>("runsprintswimmultiplier"_J, std::nullopt, false)));
		movementGroup->AddItem(std::make_shared<BoolCommandItem>("superjump"_J));
		movementGroup->AddItem(std::make_shared<BoolCommandItem>("standonvehicles"_J));
		movementGroup->AddItem(std::make_shared<BoolCommandItem>("disableactionmode"_J));

		auto freeMoveGroup = std::make_shared<Group>("Free Movement");
		freeMoveGroup->AddItem(std::make_shared<BoolCommandItem>("noclip"_J));
		freeMoveGroup->AddItem(std::make_shared<ConditionalItem>("noclip"_J, std::make_shared<FloatCommandItem>("noclipspeed"_J)));
		freeMoveGroup->AddItem(std::make_shared<BoolCommandItem>("freecam"_J));
		freeMoveGroup->AddItem(std::make_shared<ConditionalItem>("freecam"_J, std::make_shared<FloatCommandItem>("freecamspeed"_J)));

		movement->AddItem(movementGroup);
		movement->AddItem(freeMoveGroup);
		AddCategory(std::move(movement));

		// ---- Wanted ----------------------------------------------------------
		auto wanted = std::make_shared<Category>("Wanted Level");

		// "Never Wanted" and "Freeze Wanted Level" exclude each other, so each card hides while the other is on
		auto clearWantedGroup = std::make_shared<Group>("Stay Clean");
		clearWantedGroup->AddItem(std::make_shared<ConditionalItem>("neverwanted"_J, std::make_shared<CommandItem>("clearwanted"_J), true));
		clearWantedGroup->AddItem(std::make_shared<BoolCommandItem>("neverwanted"_J));

		auto setWantedGroup = std::make_shared<Group>("Set Wanted Level");
		setWantedGroup->AddItem(std::make_shared<IntCommandItem>("wantedslider"_J, "Level"));
		setWantedGroup->AddItem(std::make_shared<ConditionalItem>("freezewanted"_J, std::make_shared<CommandItem>("setwanted"_J), true));
		setWantedGroup->AddItem(std::make_shared<BoolCommandItem>("freezewanted"_J));

		wanted->AddItem(std::make_shared<ConditionalItem>("freezewanted"_J, clearWantedGroup, true));
		wanted->AddItem(std::make_shared<ConditionalItem>("neverwanted"_J, setWantedGroup, true));
		AddCategory(std::move(wanted));

		// ---- Outfits ---------------------------------------------------------
		auto outfitEditorCategory = YimMenu::CreateOutfitsMenu();
		outfitEditorCategory->m_Name = "Outfits";
		AddCategory(std::move(outfitEditorCategory));
	}

	Weapons::Weapons() :
		#define ICON_FA_CROSSHAIRS "\xef\x81\x9b"
	    Submenu::Submenu("Weapons", ICON_FA_CROSSHAIRS)
	{
		for (auto& category : BuildWeaponsCategories())
			AddCategory(std::move(category));
	}
}
