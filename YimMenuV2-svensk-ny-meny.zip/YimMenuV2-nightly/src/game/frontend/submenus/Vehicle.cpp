#include "Vehicle.hpp"
#include "game/frontend/items/Items.hpp"
#include "game/frontend/submenus/Vehicle/SpawnVehicle.hpp"
#include "Vehicle/VehicleEditor.hpp"
#include "Vehicle/SavedVehicles.hpp"

namespace YimMenu::Submenus
{
	Vehicle::Vehicle() :
		#define ICON_FA_CAR "\xef\x86\xb9"
	    Submenu::Submenu("Vehicle", ICON_FA_CAR)
	{
		auto general = std::make_shared<Category>("General");

		auto actions = std::make_shared<Group>("Quick Actions");
		actions->AddItem(std::make_shared<CommandItem>("repairvehicle"_J));
		actions->AddItem(std::make_shared<CommandItem>("fixallvehicles"_J));
		actions->AddItem(std::make_shared<CommandItem>("enterlastvehicle"_J));

		auto protection = std::make_shared<Group>("Protection");
		protection->AddItem(std::make_shared<BoolCommandItem>("vehiclegodmode"_J, "Godmode"));
		protection->AddItem(std::make_shared<BoolCommandItem>("keepfixed"_J, "Keep Fixed"));
		protection->AddItem(std::make_shared<BoolCommandItem>("seatbelt"_J));

		auto personal = std::make_shared<Group>("Personal Vehicle");
		personal->AddItem(std::make_shared<CommandItem>("requestpv"_J));
		personal->AddItem(std::make_shared<CommandItem>("callmechanic"_J));
		personal->AddItem(std::make_shared<CommandItem>("despawnpv"_J));
		personal->AddItem(std::make_shared<CommandItem>("savepersonalvehicle"_J));

		auto boost = std::make_shared<Group>("Boost");
		boost->AddItem(std::make_shared<BoolCommandItem>("hornboost"_J));
		boost->AddItem(std::make_shared<BoolCommandItem>("modifyboostbehavior"_J));
		boost->AddItem(std::make_shared<ConditionalItem>("modifyboostbehavior"_J, std::make_shared<ListCommandItem>("boostbehavior"_J)));

		auto style = std::make_shared<Group>("Style & HUD");
		style->AddItem(std::make_shared<BoolCommandItem>("speedometer"_J));
		style->AddItem(std::make_shared<BoolCommandItem>("lowervehiclestance"_J, "Lower Stance"));
		style->AddItem(std::make_shared<BoolCommandItem>("allowhatsinvehicles"_J));

		auto unlocks = std::make_shared<Group>("Unlocks");
		unlocks->AddItem(std::make_shared<BoolCommandItem>("lsccustomsbypass"_J));
		unlocks->AddItem(std::make_shared<BoolCommandItem>("dlcvehicles"_J));

		general->AddItem(actions);
		general->AddItem(protection);
		general->AddItem(personal);
		general->AddItem(boost);
		general->AddItem(style);
		general->AddItem(unlocks);

		AddCategory(std::move(general));
		AddCategory(BuildSpawnVehicleMenu());
		AddCategory(BuildVehicleEditorMenu());
		AddCategory(BuildSavedVehiclesMenu());
	}
}