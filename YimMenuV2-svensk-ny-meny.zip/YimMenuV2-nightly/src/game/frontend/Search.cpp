#include "Search.hpp"

#include "core/commands/BoolCommand.hpp"
#include "core/commands/ColorCommand.hpp"
#include "core/commands/Command.hpp"
#include "core/commands/Commands.hpp"
#include "core/commands/FloatCommand.hpp"
#include "core/commands/IntCommand.hpp"
#include "core/commands/ListCommand.hpp"
#include "core/commands/StringCommand.hpp"
#include "core/commands/Vector3Command.hpp"
#include "core/frontend/manager/Category.hpp"
#include "game/commands/PlayerCommand.hpp"
#include "game/frontend/Menu.hpp"
#include "game/frontend/items/Items.hpp"

#include <algorithm>
#include <cctype>

namespace YimMenu::Search
{
	namespace
	{
		constexpr size_t kMaxResults = 60;

		char g_Query[128]{};
		std::string g_LastQuery;
		size_t g_LastCommandCount = 0;
		size_t g_ResultCount = 0;
		std::shared_ptr<Category> g_Results;

		std::string ToLower(std::string_view s)
		{
			std::string out(s);
			std::transform(out.begin(), out.end(), out.begin(), [](unsigned char c) {
				return static_cast<char>(std::tolower(c));
			});

			// Å Ä Ö -> å ä ö (UTF-8: C3 85/84/96 -> C3 A5/A4/B6)
			for (size_t i = 0; i + 1 < out.size(); ++i)
			{
				if (static_cast<unsigned char>(out[i]) != 0xC3)
					continue;
				unsigned char& n = reinterpret_cast<unsigned char&>(out[i + 1]);
				if (n == 0x85 || n == 0x84 || n == 0x96)
					n += 0x20;
			}
			return out;
		}

		// Lower rank = better match. -1 = no match.
		int Rank(Command* command, const std::string& query)
		{
			// Labels are Swedish after translation; GetName() keeps the English id, so both languages match
			const std::string label = ToLower(command->GetLabel());
			if (label.rfind(query, 0) == 0)
				return 0;
			if (label.find(query) != std::string::npos)
				return 1;
			if (ToLower(command->GetName()).find(query) != std::string::npos)
				return 2;
			if (ToLower(command->GetDescription()).find(query) != std::string::npos)
				return 3;
			return -1;
		}

		bool IsSearchable(Command* command)
		{
			if (!command || command->GetLabel().empty())
				return false;

			// Theme colors are edited under Settings > Theme
			if (command->GetName().rfind("ColorCommand.", 0) == 0)
				return false;

			// Player-targeted commands need a selected player; they live under Players
			if (dynamic_cast<PlayerCommand*>(command) || dynamic_cast<PlayerAllCommand*>(command))
				return false;

			return true;
		}

		void Rebuild(const std::string& query)
		{
			struct Match
			{
				int rank;
				Command* command;
			};

			std::vector<Match> matches;
			for (auto& [hash, command] : Commands::GetCommands())
			{
				if (!IsSearchable(command))
					continue;

				if (int rank = Rank(command, query); rank >= 0)
					matches.push_back({rank, command});
			}

			std::sort(matches.begin(), matches.end(), [](const Match& a, const Match& b) {
				if (a.rank != b.rank)
					return a.rank < b.rank;
				return a.command->GetLabel() < b.command->GetLabel();
			});

			if (matches.size() > kMaxResults)
				matches.resize(kMaxResults);

			auto toggles = std::make_shared<Group>("Av/På");
			auto actions = std::make_shared<Group>("Åtgärder");
			auto settings = std::make_shared<Group>("Inställningar");
			bool hasToggles = false, hasActions = false, hasSettings = false;

			for (auto& [rank, command] : matches)
			{
				const auto hash = command->GetHash();

				if (dynamic_cast<BoolCommand*>(command))
				{
					toggles->AddItem(std::make_shared<BoolCommandItem>(hash));
					hasToggles = true;
				}
				else if (dynamic_cast<IntCommand*>(command))
				{
					settings->AddItem(std::make_shared<IntCommandItem>(hash));
					hasSettings = true;
				}
				else if (dynamic_cast<FloatCommand*>(command))
				{
					settings->AddItem(std::make_shared<FloatCommandItem>(hash));
					hasSettings = true;
				}
				else if (dynamic_cast<ListCommand*>(command))
				{
					settings->AddItem(std::make_shared<ListCommandItem>(hash));
					hasSettings = true;
				}
				else if (dynamic_cast<ColorCommand*>(command))
				{
					settings->AddItem(std::make_shared<ColorCommandItem>(hash));
					hasSettings = true;
				}
				else if (dynamic_cast<StringCommand*>(command))
				{
					settings->AddItem(std::make_shared<StringCommandItem>(hash));
					hasSettings = true;
				}
				else if (dynamic_cast<Vector3Command*>(command))
				{
					settings->AddItem(std::make_shared<Vector3CommandItem>(hash));
					hasSettings = true;
				}
				else
				{
					actions->AddItem(std::make_shared<CommandItem>(hash));
					hasActions = true;
				}
			}

			g_Results = std::make_shared<Category>("Search");
			if (hasActions)
				g_Results->AddItem(actions);
			if (hasToggles)
				g_Results->AddItem(toggles);
			if (hasSettings)
				g_Results->AddItem(settings);

			g_ResultCount = matches.size();
		}
	}

	void DrawSearchBar(float width)
	{
		const ImGuiStyle& style = ImGui::GetStyle();
		const float iconSlot = 30.0f;

		if (ImGui::IsKeyChordPressed(ImGuiMod_Ctrl | ImGuiKey_F))
			ImGui::SetKeyboardFocusHere();

		const ImVec2 pos = ImGui::GetCursorScreenPos();

		ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(iconSlot, style.FramePadding.y + 2.0f));
		ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 999.0f);
		ImGui::SetNextItemWidth(width);
		ImGui::InputTextWithHint("##globalsearch", "Sök funktion...   Ctrl+F", g_Query, sizeof(g_Query), ImGuiInputTextFlags_EscapeClearsAll);
		const bool focused = ImGui::IsItemActive();
		const ImVec2 size = ImGui::GetItemRectSize();
		ImGui::PopStyleVar(2);

		// Magnifier icon
		ImDrawList* dl = ImGui::GetWindowDrawList();
		if (ImFont* iconFont = Menu::Font::g_AwesomeFont)
		{
			const char* icon = "\xef\x80\x82"; // magnifying-glass
			const float iconSize = 14.0f;
			const ImVec2 ts = iconFont->CalcTextSizeA(iconSize, FLT_MAX, 0.0f, icon);
			const ImU32 col = focused ? ImGui::GetColorU32(ImGuiCol_CheckMark) : ImGui::GetColorU32(ImGuiCol_TextDisabled);
			dl->AddText(iconFont, iconSize, ImVec2(pos.x + (iconSlot - ts.x) * 0.5f + 2.0f, pos.y + (size.y - ts.y) * 0.5f), col, icon);
		}

		// Accent outline while typing
		if (focused)
			dl->AddRect(pos, pos + size, ImGui::GetColorU32(ImGuiCol_CheckMark, 0.7f), size.y * 0.5f, 0, 1.5f);
	}

	bool IsActive()
	{
		return g_Query[0] != '\0';
	}

	void DrawResults()
	{
		const std::string query = ToLower(g_Query);
		const size_t commandCount = Commands::GetCommands().size();

		if (!g_Results || query != g_LastQuery || commandCount != g_LastCommandCount)
		{
			Rebuild(query);
			g_LastQuery = query;
			g_LastCommandCount = commandCount;
		}

		if (g_ResultCount == 0)
		{
			ImGui::Dummy(ImVec2(0.0f, 30.0f));
			ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyle().Colors[ImGuiCol_TextDisabled]);
			const char* line1 = "Inga funktioner matchar din sökning.";
			const char* line2 = "Prova ett kortare ord, t.ex. \"gud\", \"reparera\" eller \"väder\".";
			const float avail = ImGui::GetContentRegionAvail().x;
			ImGui::SetCursorPosX(ImGui::GetCursorPosX() + std::max(0.0f, (avail - ImGui::CalcTextSize(line1).x) * 0.5f));
			ImGui::TextUnformatted(line1);
			ImGui::SetCursorPosX(ImGui::GetCursorPosX() + std::max(0.0f, (avail - ImGui::CalcTextSize(line2).x) * 0.5f));
			ImGui::TextUnformatted(line2);
			ImGui::PopStyleColor();
			return;
		}

		ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyle().Colors[ImGuiCol_TextDisabled]);
		ImGui::Text("%zu träff%s%s", g_ResultCount, g_ResultCount == 1 ? "" : "ar", g_ResultCount >= kMaxResults ? " (visar de första 60)" : "");
		ImGui::PopStyleColor();
		ImGui::Spacing();

		g_Results->Draw();
	}

	void Clear()
	{
		g_Query[0] = '\0';
		g_Results.reset();
		g_LastQuery.clear();
	}
}
