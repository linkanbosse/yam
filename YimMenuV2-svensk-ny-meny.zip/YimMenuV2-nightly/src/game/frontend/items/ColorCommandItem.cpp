#include "Items.hpp"
#include "core/frontend/Translate.hpp"
#include "core/frontend/manager/Layout.hpp"
#include "core/commands/ColorCommand.hpp"
#include "core/commands/Command.hpp"
#include "core/commands/Commands.hpp"
#include "core/frontend/widgets/toggle/imgui_toggle.hpp"

namespace YimMenu
{
	ColorCommandItem::ColorCommandItem(joaat_t id, std::optional<std::string> labelOverride) :
	    m_Command(Commands::GetCommand<ColorCommand>(id)),
	    m_LabelOverride(labelOverride)
	{
	}

	void ColorCommandItem::Draw()
	{
		if (!m_Command)
		{
			ImGui::Text(Tr("Unknown color picker!"));
			return;
		}

		auto color = m_Command->GetState();
		auto label = m_LabelOverride.has_value() ? Tr(m_LabelOverride.value()) : m_Command->GetLabel().c_str();

		// Normally sits next to the toggle above it; in a card with descriptions it gets its own row
		const bool ownRow = Layout::g_DescriptionTarget == this && ShowDescriptions();
		if (!ownRow)
			ImGui::SameLine();

		ImGui::SetNextItemWidth(150);
		if (ImGui::ColorButton(label, color))
		{
			ImGui::OpenPopup(label);
		}

		if (ImGui::BeginPopup(label))
		{
			if (ImGui::ColorPicker4("##picker", (float*)&color))
			{
				m_Command->SetState(color);
			}
			ImGui::EndPopup();
		}

		if (ownRow)
		{
			ImGui::SameLine();
			const char* idStart = std::strstr(label, "##");
			ImGui::TextUnformatted(label, idStart);
		}
	}
}