#include "Items.hpp"
#include "core/frontend/manager/ListMenu.hpp"
#include "core/frontend/Translate.hpp"
#include "core/frontend/manager/Layout.hpp"
#include "core/commands/Command.hpp"
#include "core/commands/Commands.hpp"
#include "core/commands/ListCommand.hpp"
#include "core/frontend/widgets/toggle/imgui_toggle.hpp"

namespace YimMenu
{
	ListCommandItem::ListCommandItem(joaat_t id, std::optional<std::string> label_override) :
	    m_Command(Commands::GetCommand<ListCommand>(id)),
	    m_LabelOverride(label_override)
	{
	}

	void ListCommandItem::Draw()
	{
		if (!m_Command)
		{
			ImGui::TextUnformatted(Tr("Unknown list!"));
			return;
		}

		int current_val = m_Command->GetState();
		auto& list = m_Command->GetList();

		if (ListMenu::g_Active)
		{
			auto row = ListMenu::BeginRow(this, m_Command->GetDescription());
			ListMenu::Label(row, m_LabelOverride.has_value() ? Tr(m_LabelOverride.value()) : m_Command->GetLabel().c_str());

			int index = 0;
			for (int i = 0; i < (int)list.size(); ++i)
				if (list[i].first == current_val)
					index = i;

			ListMenu::ValueSelector(row, list.empty() ? "-" : TrOption(list[index].second));

			const int step = row.Delta != 0 ? row.Delta : (row.Activated ? 1 : 0);
			if (step != 0 && !list.empty())
			{
				const int next = (index + step + (int)list.size()) % (int)list.size();
				m_Command->SetState(list[next].first);
				m_SelectedItem = TrOption(list[next].second);
			}
			return;
		}
		const char* largest_string = "";
		std::size_t largest_string_len = 0;

		if (!m_SelectedItem.has_value() || !m_ItemWidth.has_value())
		{
			for (auto& item : list)
			{
				const char* text = TrOption(item.second);
				if (item.first == current_val)
				{
					m_SelectedItem = text;
				}

				int length = strlen(text);
				if (length > largest_string_len)
				{
					largest_string = text;
					largest_string_len = length;
				}
			}

			if (!m_SelectedItem.has_value())
				m_SelectedItem = "";

			auto size = ImGui::CalcTextSize(largest_string);
			m_ItemWidth = size.x + 40.0f;
		}

		ImGui::SetNextItemWidth(m_ItemWidth.value());
		if (ImGui::BeginCombo(m_LabelOverride.has_value() ? Tr(m_LabelOverride.value()) : m_Command->GetLabel().c_str(), m_SelectedItem.value().c_str()))
		{
			for (auto& el : list)
			{
				if (ImGui::Selectable(TrOption(el.second), el.first == current_val))
				{
					current_val = el.first;
					m_Command->SetState(el.first);
				}

				if (el.first == current_val)
				{
					m_SelectedItem = TrOption(el.second); // just in case
					ImGui::SetItemDefaultFocus();
				}
			}
			ImGui::EndCombo();
		}

		DrawItemDescription(this, m_Command->GetDescription());
	}
}