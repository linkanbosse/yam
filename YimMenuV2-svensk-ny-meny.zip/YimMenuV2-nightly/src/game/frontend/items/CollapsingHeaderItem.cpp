#include "Items.hpp"
#include "core/frontend/Translate.hpp"
#include "core/frontend/manager/Layout.hpp"

namespace YimMenu
{
	CollapsingHeaderItem::CollapsingHeaderItem(const std::string& name) :
	    m_Name(name)
	{
	}

	void CollapsingHeaderItem::Draw()
	{
		if (ImGui::CollapsingHeader(Tr(m_Name)))
		{
			for (auto& item : m_Items)
			{
				if (item->CanDraw())
					item->Draw();
			}
		}
	}
}