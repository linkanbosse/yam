#include "Items.hpp"
#include "core/frontend/manager/ListMenu.hpp"
#include "core/frontend/Translate.hpp"
#include "core/frontend/manager/Layout.hpp"
#include "core/commands/Command.hpp"
#include "core/commands/Commands.hpp"
#include "core/commands/FloatCommand.hpp"
#include "core/frontend/widgets/toggle/imgui_toggle.hpp"

namespace YimMenu
{
	FloatCommandItem::FloatCommandItem(joaat_t id, std::optional<std::string> label_override, bool use_slider) :
	    m_useSlider(use_slider),
	    m_Command(Commands::GetCommand<FloatCommand>(id)),
	    m_LabelOverride(label_override)
	{
	}

	void FloatCommandItem::Draw()
	{
		if (!m_Command)
		{
			ImGui::Text(Tr("Unknown!"));
			return;
		}

		auto value = m_Command->GetState();
		auto label = m_LabelOverride.has_value() ? Tr(m_LabelOverride.value()) : m_Command->GetLabel().c_str();

		if (ListMenu::g_Active)
		{
			auto row = ListMenu::BeginRow(this, m_Command->GetDescription());
			ListMenu::Label(row, label);
			char text[32];
			std::snprintf(text, sizeof(text), "%.2f", value);
			ListMenu::ValueSelector(row, text);
			if (row.Delta != 0)
			{
				const auto min = m_Command->GetMinimum();
				const auto max = m_Command->GetMaximum();
				const float step = (min.has_value() && max.has_value() && max.value() > min.value()) ? (max.value() - min.value()) / 20.0f : 0.1f;
				float next = value + row.Delta * step;
				if (min.has_value())
					next = std::max(next, (float)min.value());
				if (max.has_value())
					next = std::min(next, (float)max.value());
				m_Command->SetState(next);
			}
			return;
		}
		if (!m_Command->GetMinimum().has_value() || !m_Command->GetMaximum().has_value() || !m_useSlider)
		{
			ImGui::SetNextItemWidth(150);
			if (ImGui::InputFloat(label, &value))
			{
				m_Command->SetState(value);
			}
		}
		else
		{
			ImGui::SetNextItemWidth(150);
			if (ImGui::SliderFloat(label, &value, m_Command->GetMinimum().value(), m_Command->GetMaximum().value()))
			{
				m_Command->SetState(value);
			}
		}

		DrawItemDescription(this, m_Command->GetDescription());
	}
}