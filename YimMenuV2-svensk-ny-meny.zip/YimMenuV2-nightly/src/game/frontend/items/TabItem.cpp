#include "Items.hpp"
#include "core/frontend/Translate.hpp"
#include "core/frontend/manager/Layout.hpp"

namespace YimMenu
{
	TabItem::TabItem(const std::string& name) :
	    m_Name(name)
	{
	}

	void TabItem::Draw()
	{
		if (ImGui::BeginTabItem(Tr(m_Name)))
		{
			for (auto& item : m_Items)
			{
				if (item->CanDraw())
					item->Draw();
			}
			ImGui::EndTabItem();
		}
	}
}
