#include "Items.hpp"
#include "core/commands/Command.hpp"
#include "core/commands/Commands.hpp"
#include "core/backend/FiberPool.hpp"
#include "core/frontend/manager/Layout.hpp"
#include "core/frontend/Translate.hpp"
#include "game/frontend/Menu.hpp"

namespace YimMenu
{
	Group::Group(const std::string& name, int items_per_column) :
	    m_Name(name),
	    m_ItemsPerColumn(items_per_column)
	{
	}

	// Card header: small accent pill + title
	static void DrawCardTitle(const std::string& name)
	{
		const ImGuiStyle& style = ImGui::GetStyle();
		ImDrawList* dl = ImGui::GetWindowDrawList();

		const ImVec2 p = ImGui::GetCursorScreenPos();
		const float h = ImGui::GetTextLineHeight();
		dl->AddRectFilled(ImVec2(p.x, p.y + h * 0.15f), ImVec2(p.x + 3.0f, p.y + h * 0.85f), ImGui::GetColorU32(style.Colors[ImGuiCol_CheckMark]), 2.0f);

		ImGui::SetCursorScreenPos(ImVec2(p.x + 11.0f, p.y));
		ImGui::TextUnformatted(Tr(name));
		ImGui::Dummy(ImVec2(0.0f, 4.0f));
	}

	// Inside a card: one clean vertical list, with runs of plain buttons laid out as a 2-column grid
	void Group::DrawCardContent()
	{
		const float spacing = ImGui::GetStyle().ItemSpacing.x;

		std::vector<UIItem*> visible;
		for (auto& item : m_Items)
			if (item->CanDraw())
				visible.push_back(item.get());

		for (size_t i = 0; i < visible.size(); ++i)
		{
			if (!visible[i]->IsButton())
			{
				Layout::g_DescriptionTarget = visible[i];
				visible[i]->Draw();
				Layout::g_DescriptionTarget = nullptr;
				continue;
			}

			// Collect the run of consecutive buttons
			size_t end = i;
			while (end < visible.size() && visible[end]->IsButton())
				++end;

			const size_t count = end - i;
			const float avail = ImGui::GetContentRegionAvail().x;
			const float half = std::floor((avail - spacing) * 0.5f);

			// Two columns only when descriptions are off and every label fits in half the card
			bool twoCols = count > 1 && !ShowDescriptions();
			for (size_t j = i; j < end && twoCols; ++j)
				twoCols = visible[j]->GetButtonWidth() <= half;

			const float width = twoCols ? half : avail;

			const float oldWidth = Layout::g_ButtonWidth;
			Layout::g_ButtonWidth = width;
			for (size_t j = 0; j < count; ++j)
			{
				if (twoCols && (j % 2) == 1)
					ImGui::SameLine(0.0f, spacing);
				Layout::g_DescriptionTarget = visible[i + j];
				visible[i + j]->Draw();
				Layout::g_DescriptionTarget = nullptr;
			}
			Layout::g_ButtonWidth = oldWidth;

			i = end - 1;
		}
	}

	void Group::Draw()
	{
		if (Layout::g_InCard)
		{
			if (!m_Name.empty())
				DrawCardTitle(m_Name);

			DrawCardContent();
			return;
		}

		if (!m_Name.empty())
		{
			ImGui::PushFont(Menu::Font::g_ChildTitleFont);
			ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyle().Colors[ImGuiCol_CheckMark]);
			ImGui::TextUnformatted(Tr(m_Name));
			ImGui::PopStyleColor();
			ImGui::PopFont();
			ImGui::Separator();
			ImGui::Spacing();
		}

		int item_count = 0;

		ImGui::BeginGroup();
		for (auto& item : m_Items)
		{
			if (!item->CanDraw())
				continue;

			item->Draw();
			item_count++;

			if (m_ItemsPerColumn != -1 && item_count % m_ItemsPerColumn == 0)
			{
				ImGui::EndGroup();
				ImGui::SameLine();
				ImGui::BeginGroup();
			}
		}
		ImGui::EndGroup();
	}
}
