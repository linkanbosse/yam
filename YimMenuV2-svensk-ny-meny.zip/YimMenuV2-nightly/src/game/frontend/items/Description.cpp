#include "Items.hpp"
#include "core/commands/BoolCommand.hpp"
#include "core/frontend/manager/Layout.hpp"
#include "game/frontend/Menu.hpp"

namespace YimMenu
{
	static BoolCommand _ShowDescriptions{"showdescriptions", "Show Descriptions", "Show a short explanation under every feature in the menu", true};

	bool ShowDescriptions()
	{
		return _ShowDescriptions.GetState();
	}

	void DrawItemDescription(const UIItem* item, const std::string& text, float indent, float raise)
	{
		if (text.empty() || Layout::g_DescriptionTarget != item || !ShowDescriptions())
			return;

		const ImGuiStyle& style = ImGui::GetStyle();

		// Pull the text up a bit so it reads as part of the control above
		ImGui::SetCursorPosY(ImGui::GetCursorPosY() - style.ItemSpacing.y * 0.6f - raise);
		ImGui::SetCursorPosX(ImGui::GetCursorPosX() + indent);

		if (Menu::Font::g_ChildTitleFont)
			ImGui::PushFont(Menu::Font::g_ChildTitleFont);
		ImGui::PushStyleColor(ImGuiCol_Text, style.Colors[ImGuiCol_TextDisabled]);
		ImGui::PushTextWrapPos(0.0f);
		ImGui::TextUnformatted(text.c_str());
		ImGui::PopTextWrapPos();
		ImGui::PopStyleColor();
		if (Menu::Font::g_ChildTitleFont)
			ImGui::PopFont();

		ImGui::Dummy(ImVec2(0.0f, 2.0f));
	}
}
