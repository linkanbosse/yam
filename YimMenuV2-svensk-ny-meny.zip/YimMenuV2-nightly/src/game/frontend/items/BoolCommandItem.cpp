#include "Items.hpp"
#include "core/frontend/manager/ListMenu.hpp"
#include "core/frontend/Translate.hpp"
#include "core/frontend/manager/Layout.hpp"
#include "core/commands/Commands.hpp"
#include "core/commands/Command.hpp"
#include "core/commands/LoopedCommand.hpp"
#include "core/frontend/widgets/toggle/imgui_toggle.hpp"

namespace YimMenu
{
	BoolCommandItem::BoolCommandItem(joaat_t id, std::optional<std::string> label_override) :
	    m_Command(Commands::GetCommand<BoolCommand>(id)),
	    m_LabelOverride(label_override)
	{
	}

	void BoolCommandItem::Draw()
	{
		if (!m_Command)
		{
			ImGui::Text(Tr("Unknown!"));
			return;
		}

		bool enabled = m_Command->GetState();

		if (ListMenu::g_Active)
		{
			auto row = ListMenu::BeginRow(this, m_Command->GetDescription());
			ListMenu::Label(row, m_LabelOverride.has_value() ? Tr(m_LabelOverride.value()) : m_Command->GetLabel().c_str());
			ListMenu::ToggleBox(row, enabled);
			if (row.Activated || row.Delta != 0)
				m_Command->SetState(!enabled);
			return;
		}
		if (ImGui::Toggle(m_LabelOverride.has_value() ? Tr(m_LabelOverride.value()) : m_Command->GetLabel().data(), &enabled))
			m_Command->SetState(enabled);

		// TODO: refactor this

		auto windowLabel = std::format("Snabbtangent: {}", m_Command->GetLabel());

		if (ImGui::IsItemHovered())
		{
			ImGui::SetTooltip("%s", m_Command->GetDescription().data());
			if (GetAsyncKeyState(VK_OEM_3) & 0x8000)
				ImGui::OpenPopup(std::format("Snabbtangent: {}", m_Command->GetLabel()).data());
		}

		ImGui::SetNextWindowSize(ImVec2(500, 120));
		if (ImGui::BeginPopupModal(windowLabel.data(), nullptr, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar))
		{
			ImGui::BulletText("%s", Tr("Hover over the command name to change its hotkey"));
			ImGui::BulletText("%s", Tr("Press any registered key to remove"));
			ImGui::Separator();


			ImGui::Spacing();
			if (ImGui::Button(Tr("Close")) || ((!ImGui::IsWindowHovered() && !ImGui::IsAnyItemHovered()) && ImGui::IsMouseClicked(ImGuiMouseButton_Left)))
				ImGui::CloseCurrentPopup();

			ImGui::EndPopup();
		}

		// Explanation lines up with the label, to the right of the switch
		DrawItemDescription(this, m_Command->GetDescription(), ImGui::GetFrameHeight() * 1.618f + ImGui::GetStyle().ItemInnerSpacing.x, ImGui::GetStyle().FramePadding.y + 6.0f);
	}
}