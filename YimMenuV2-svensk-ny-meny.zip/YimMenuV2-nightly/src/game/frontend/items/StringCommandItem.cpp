#include "Items.hpp"
#include "core/frontend/Translate.hpp"
#include "core/frontend/manager/Layout.hpp"
#include "core/commands/Commands.hpp"
#include "core/commands/StringCommand.hpp"
#include "imgui.h"

namespace YimMenu
{
	StringCommandItem::StringCommandItem(joaat_t id, std::optional<std::string> label_override) :
	    m_Command(Commands::GetCommand<StringCommand>(id)),
	    m_LabelOverride(label_override)
	{
	}

	void StringCommandItem::Draw()
	{
		if (!m_Command)
		{
			ImGui::Text(Tr("Unknown string command!"));
			return;
		}

		std::string current_value = m_Command->GetString();
		char buffer[256];
		memset(buffer, 0, sizeof(buffer));
		memcpy(buffer, current_value.c_str(), current_value.size());

		ImGui::SetNextItemWidth(300.0f);
		if (ImGui::InputText(m_LabelOverride.has_value() ? Tr(m_LabelOverride.value()) : m_Command->GetLabel().c_str(), buffer, sizeof(buffer)))
		{
			m_Command->SetStringValue(buffer);
		}

		DrawItemDescription(this, m_Command->GetDescription());
	}
}
