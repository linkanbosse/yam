#pragma once

namespace YimMenu::Search
{
	// Search field for the page header. Ctrl+F focuses it, Escape clears it.
	void DrawSearchBar(float width);

	// True while there is text in the search field
	bool IsActive();

	// Draws the matching features as cards (Toggles / Actions / Settings)
	void DrawResults();

	void Clear();
}
